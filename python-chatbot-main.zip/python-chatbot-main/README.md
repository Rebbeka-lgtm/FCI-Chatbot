# python-chatbot
python-chatbot

### Install required modules
```
pip install -r requirements.txt
```

### Train the model
```
python train_bot.py
```

### Testing
```
python chatgui.py
```