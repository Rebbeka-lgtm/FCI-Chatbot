#imports
import nltk, json, random, pickle
from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()
import pickle
import numpy as np
from random import randint
from tensorflow.keras.models import load_model
from datetime import datetime
#custom objects
class student_info: 
    def __init__(self, name, student_number): 
        self.name = name 
        self.student_number = student_number
class application: 
    def __init__(self, student_number, status, program,date): 
        self.student_number = student_number 
        self.status = status
        self.program = program
        self.date = date 
class f_a_q: 
    def __init__(self, question, number): 
        self.question = question
        self.number = number
#lists              
faq=[]             
students=[]
applications=[]
#hardcored list of students
students.append(student_info("John Doe","219053138"))
students.append(student_info("Mary Jane","219053118"))
students.append(student_info("Tommy Lee","219053128"))
#load files
model = load_model('chatbot_model.h5')
intents = json.loads(open('intents.json').read())
words = pickle.load(open('words.pkl','rb'))
classes = pickle.load(open('classes.pkl','rb'))
#function for calculating random visitor's id
def random_with_N_digits(n):
    range_start = 10**(n-1)
    range_end = (10**n)-1
    return randint(range_start, range_end)
#Cleanup the sentence before computing    
def clean_up_sentence(sentence):
    sentence_words = nltk.word_tokenize(sentence)
    sentence_words = [lemmatizer.lemmatize(word.lower()) for word in sentence_words]
    return sentence_words

# creating a bag of words
def bow(sentence, words, show_details=True):
    sentence_words = clean_up_sentence(sentence)
    bag = [0]*len(words)
    for s in sentence_words:
        for i,w in enumerate(words):
            if w == s:
                bag[i] = 1
                if show_details:
                    print ("found in bag: %s" % w)
    return(np.array(bag))
#function for prediction
def calcola_pred(sentence, model):
    p = bow(sentence, words,show_details=False)
    res = model.predict(np.array([p]))[0]
    ERROR_THRESHOLD = 0.25
    results = [[i,r] for i,r in enumerate(res) if r>ERROR_THRESHOLD]
    # sort by strength of probability
    results.sort(key=lambda x: x[1], reverse=True)
    return_list = []
    for r in results:
        return_list.append({"intent": classes[r[0]], "probability": str(r[1])})
    return return_list
#function for loading the intents and responses
def getRisposta(ints, intents_json):
    tag = ints[0]['intent']
    list_of_intents = intents_json['intents']
    for i in list_of_intents:
        if(i['tag']== tag):
            result = random.choice(i['responses'])
            break
    return result
#function for loading the response from model
def inizia(msg):
    ints = calcola_pred(msg, model)
    res = getRisposta(ints, intents)
    return res
#the chatbot function    
def chatBot():
    inp = ''
    print("Start talking with the bot (type quit to stop)!")

    while inp != 'quit':
        inp = str(input(""))
        found = False
        for q in faq:
          if q.question.lower() == inp.lower():
             q.number = q.number+1
             found = True
        if found == False:
          if inp.lower() != 'quit':
             faq.append(f_a_q(inp.lower(),1))
        res = inizia(inp)
        print('AI:' + res)
    chat()   
#function for statistics of FAQ
def displayFAQ():
    print("Frequently Asked Questions \n")
    for w in faq:
       print("Question: "+w.question+"\n")
       print("Times Asked: ",w.number)
       print("\n")
    chat()
#The main system homepage
def chat():
    val = input("Hello User,welcome to the Faculty of Computing and Informatics (FCI). My name id Pandu the Chatbot. \n Enter '1': If you are a Student, \n Enter '2': If you are an Applicant and want to make an application, \n Enter '3': If you are a Visitor, \n Enter '4': See Frequently Asked Questions \n")
    print(val)
    if val == '1':
        student_number = 0
        student_name = ""
        val = input("Enter your Student Number:")
        for x in students:
            if(x.student_number == val):
                student_number = val
                student_name = x.name
        if(student_number == 0):
            print("Error, student number does not exist")
            chat()
        else:
           val1 = input("Welcome "+student_name+"\n To interact with the Chatbot Enter '1' \n To get the status of your application Enter '2' \n")  
           if(val1 == '2'):
                found = False
                status = ""
                for x in applications:
                    if(val == x.student_number):
                        status=x.status
                        found=True
                if(found == True):
                    print("Your application is "+status)
                else:
                    print("Application not found")   
           elif(val1 == '1'):
              chatBot()
           else:
              print("Error, invalid option try again")
              chat()
    elif(val == '2'):
        student_number = 0
        val3 = input("Welcome Applicant. Enter '1' for Enquires | Enter '2' to make an Application: \n")
        if(val3 == '1'):
            chatBot()
        elif(val3 == '2') :
            for x in students:
                if(x.student_number == val):
                    student_number = val
            if(student_number == 0):
                    print("Error, student number does not exist")
                    chat()
            else:
                make_application(student_number)   
        else:
          print("Error, student number does not exist")
          chat()
    elif(val == '3'):
        print("Welcome Visitor ID: ",random_with_N_digits(4))
        print("\n")
        chatBot()
    elif(val == '4'):
        displayFAQ()    
    else:
        print("Error, please enter correct input value")
        chat()
    
def make_application(roll):
      val = input("Enter your the program that you are applying for: \n Enter '1'for PhD Informatics/Computer Science \n Enter '2' for Masters (Computer Science, Informatics) \n Enter '3'for Masters Data Science \n Enter '4' for Honours in Computer Science and Informatics \n")
      if(val == '1'):
        applications.append(application(roll,"Pending","PhD Informatics/Computer Science",datetime.today().strftime('%Y-%m-%d')))
      
      elif(val == '2'):
         applications.append(application(roll,"Pending"," Masters (Computer Science, Informatics)",datetime.today().strftime('%Y-%m-%d')))     
      elif(val == '3'):
        applications.append(application(roll,"Pending"," Masters Data Science",datetime.today().strftime('%Y-%m-%d')))
      elif(val == '4'):
        applications.append(application(roll,"Pending"," Honours in Computer Science and Informatics",datetime.today().strftime('%Y-%m-%d')))
      else:
        print("Error, input the correct value")
        make_application(roll)
      
#initiate the conversation
if __name__ == "__main__":
    chat()
